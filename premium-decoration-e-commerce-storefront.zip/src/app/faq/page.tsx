import { db } from "@/db";
import { faqs } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function FaqPage() {
  const rows = await db.select().from(faqs).orderBy(faqs.sortOrder);
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-3xl text-brand">الأسئلة الشائعة</h1>
      <div className="mt-6 space-y-4">
        {rows.map((f) => (
          <details key={f.id} className="rounded-2xl bg-white p-4 shadow-sm">
            <summary className="cursor-pointer font-semibold text-brand">
              {f.questionAr}
            </summary>
            <p className="mt-2 text-sm text-ink/80">{f.answerAr}</p>
          </details>
        ))}
        {rows.length === 0 && <p className="text-muted">لا توجد أسئلة بعد.</p>}
      </div>
    </div>
  );
}