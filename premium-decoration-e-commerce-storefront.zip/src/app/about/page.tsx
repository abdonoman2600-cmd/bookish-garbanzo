import { db } from "@/db";
import { pages } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const [p] = await db.select().from(pages).where(eq(pages.slug, "about"));
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-3xl text-brand">{p?.titleAr || "من نحن"}</h1>
      <div className="mt-6 whitespace-pre-line leading-relaxed text-ink/80">
        {p?.contentAr || "صفحة من نحن قيد الإعداد."}
      </div>
    </div>
  );
}