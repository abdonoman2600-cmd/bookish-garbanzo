"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useI18n } from "@/lib/i18n";

export default function AccountPage() {
  const [user, setUser] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const { t } = useI18n();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setUser(d.user));
    fetch("/api/account/orders")
      .then((r) => r.json())
      .then((d) => setOrders(d.orders ?? []));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/";
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <p>يرجى تسجيل الدخول</p>
        <Link href="/login" className="mt-4 inline-block rounded-full bg-brand px-6 py-2 text-cream">
          {t("login")}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-brand">{t("account")}</h1>
        <button onClick={logout} className="text-sm text-muted hover:text-red-600">
          {t("logout")}
        </button>
      </div>
      <div className="mt-4 rounded-2xl bg-white p-5 shadow-sm">
        <p className="font-semibold">{user.name}</p>
        <p className="text-sm text-muted">{user.email}</p>
        <p className="text-sm text-muted">{user.role}</p>
      </div>
      <h2 className="mt-8 font-display text-xl text-brand">{t("orders")}</h2>
      <div className="mt-3 overflow-x-auto rounded-2xl bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="p-3 text-right">#</th>
              <th className="p-3 text-right">المجموع</th>
              <th className="p-3 text-right">الحالة</th>
              <th className="p-3 text-right">التاريخ</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-t border-black/5">
                <td className="p-3">{o.id}</td>
                <td className="p-3">{Number(o.total).toFixed(2)} ر.س</td>
                <td className="p-3">{o.status}</td>
                <td className="p-3">{new Date(o.createdAt).toLocaleDateString("ar-SA")}</td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-muted">
                  لا توجد طلبات
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}