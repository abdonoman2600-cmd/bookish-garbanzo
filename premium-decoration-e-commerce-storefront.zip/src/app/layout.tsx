import type { Metadata } from "next";
import { Cairo, Reem_Kufi } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/lib/cart";
import { AdminProvider } from "@/lib/admin";
import { I18nProvider } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import EditToolbar from "@/components/EditToolbar";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
  display: "swap",
});

const reem = Reem_Kufi({
  subsets: ["arabic", "latin"],
  variable: "--font-reem",
  display: "swap",
});

export const metadata: Metadata = {
  title: "رشيد | أعمال ديكور وجبسن بورد",
  description:
    "متجر رشيد للأعمال الديكورية وجبسن بورد — تشكيلات فاخرة من الأسقف المستعارة، الديكور الجداري، الإضاءة والملحقات.",
  openGraph: {
    title: "رشيد | أعمال ديكور وجبسن بورد",
    description:
      "تشكيلات فاخرة من الأسقف المستعارة، الديكور الجداري، الإضاءة والملحقات.",
    type: "website",
    locale: "ar_SA",
    siteName: "رشيد",
  },
  twitter: {
    card: "summary_large_image",
    title: "رشيد | أعمال ديكور وجبسن بورد",
    description:
      "تشكيلات فاخرة من الأسقف المستعارة، الديكور الجداري، الإضاءة والملحقات.",
  },
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${cairo.variable} ${reem.variable}`}
      style={
        {
          "--color-brand": s.brand_color,
          "--color-brand-light": s.brand_color,
          "--color-accent": s.accent_color,
        } as any
      }
    >
      <body className="min-h-screen bg-cream text-ink antialiased">
        <AdminProvider>
          <I18nProvider>
            <CartProvider>
            <Header />
            <CartDrawer />
            <main className="min-h-[60vh]">{children}</main>
            <Footer />
            <EditToolbar />
          </CartProvider>
          </I18nProvider>
        </AdminProvider>
      </body>
    </html>
  );
}