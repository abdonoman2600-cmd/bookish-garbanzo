import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json();
  const { name, email, password } = body;
  if (!name || !email || !password) {
    return NextResponse.json({ error: "missing fields" }, { status: 400 });
  }
  const existing = await db.select().from(users).where(eq(users.email, email));
  if (existing.length > 0) {
    return NextResponse.json({ error: "email exists" }, { status: 409 });
  }
  const hash = await bcrypt.hash(password, 10);
  const [u] = await db
    .insert(users)
    .values({ name, email, passwordHash: hash, role: "customer" })
    .returning();
  const res = NextResponse.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
  res.cookies.set("customer_token", String(u.id), { httpOnly: true, path: "/", maxAge: 60 * 60 * 24 * 7 });
  return res;
}