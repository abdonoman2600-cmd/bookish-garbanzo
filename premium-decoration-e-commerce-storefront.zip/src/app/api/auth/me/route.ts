import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const cookie = req.headers.get("cookie") || "";
  const match = cookie.match(/customer_token=([^;]+)/);
  const id = match ? Number(match[1]) : null;
  if (!id) return NextResponse.json({ user: null });
  const [u] = await db.select().from(users).where(eq(users.id, id));
  if (!u) return NextResponse.json({ user: null });
  return NextResponse.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
}