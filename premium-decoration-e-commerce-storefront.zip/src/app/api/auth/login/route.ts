import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json();
  const { email, password } = body;
  const [u] = await db.select().from(users).where(eq(users.email, email));
  if (!u) return NextResponse.json({ error: "invalid" }, { status: 401 });
  const ok = await bcrypt.compare(password, u.passwordHash);
  if (!ok) return NextResponse.json({ error: "invalid" }, { status: 401 });
  const res = NextResponse.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
  res.cookies.set("customer_token", String(u.id), { httpOnly: true, path: "/", maxAge: 60 * 60 * 24 * 7 });
  return res;
}