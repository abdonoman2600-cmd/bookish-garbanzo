import { db } from "@/db";
import { reviews } from "@/db/schema";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { productId, authorName, rating, comment } = body;
    if (!productId || !authorName) {
      return NextResponse.json({ error: "missing fields" }, { status: 400 });
    }
    const [review] = await db
      .insert(reviews)
      .values({
        productId: Number(productId),
        authorName: String(authorName),
        rating: Number(rating) || 5,
        comment: comment ? String(comment) : null,
      })
      .returning();
    return NextResponse.json({ review });
  } catch (e) {
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}