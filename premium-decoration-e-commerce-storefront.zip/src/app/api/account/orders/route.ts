import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const cookie = req.headers.get("cookie") || "";
  const match = cookie.match(/customer_token=([^;]+)/);
  const id = match ? Number(match[1]) : null;
  if (!id) return NextResponse.json({ orders: [] }, { status: 401 });
  const rows = await db.select().from(orders).where(eq(orders.customerId, id));
  return NextResponse.json({ orders: rows });
}