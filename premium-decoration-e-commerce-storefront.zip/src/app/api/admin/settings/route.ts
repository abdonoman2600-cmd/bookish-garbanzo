import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { NextResponse } from "next/server";
import { setSetting } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(siteSettings);
  return NextResponse.json({ settings: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  for (const [key, value] of Object.entries(body)) {
    await setSetting(key, String(value ?? ""));
  }
  return NextResponse.json({ ok: true });
}