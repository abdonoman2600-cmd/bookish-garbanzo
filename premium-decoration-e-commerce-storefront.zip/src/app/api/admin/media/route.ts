import { readdir, unlink } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

export async function GET() {
  try {
    const files = await readdir(UPLOAD_DIR);
    const urls = files.map((f) => `/uploads/${f}`);
    return NextResponse.json({ files: urls });
  } catch {
    return NextResponse.json({ files: [] });
  }
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url");
  if (!url) return NextResponse.json({ error: "missing url" }, { status: 400 });
  const filename = path.basename(url);
  try {
    await unlink(path.join(UPLOAD_DIR, filename));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}