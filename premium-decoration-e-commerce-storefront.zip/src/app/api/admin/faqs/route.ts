import { db } from "@/db";
import { faqs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(faqs).orderBy(faqs.sortOrder);
  return NextResponse.json({ faqs: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  if (body.id) {
    const [f] = await db
      .update(faqs)
      .set({
        questionAr: body.questionAr,
        questionEn: body.questionEn,
        answerAr: body.answerAr,
        answerEn: body.answerEn,
        sortOrder: body.sortOrder ?? 0,
      })
      .where(eq(faqs.id, body.id))
      .returning();
    return NextResponse.json({ faq: f });
  }
  const [f] = await db
    .insert(faqs)
    .values({
      questionAr: body.questionAr,
      questionEn: body.questionEn,
      answerAr: body.answerAr,
      answerEn: body.answerEn,
      sortOrder: body.sortOrder ?? 0,
    })
    .returning();
  return NextResponse.json({ faq: f });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  await db.delete(faqs).where(eq(faqs.id, Number(id)));
  return NextResponse.json({ ok: true });
}