import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(categories).orderBy(categories.id);
  return NextResponse.json({ categories: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const [c] = await db
    .insert(categories)
    .values({
      name: String(body.name),
      slug: String(body.slug),
      description: body.description ? String(body.description) : null,
      image: body.image ? String(body.image) : null,
    })
    .returning();
  return NextResponse.json({ category: c });
}

export async function PUT(req: Request) {
  const body = await req.json();
  const [c] = await db
    .update(categories)
    .set({
      name: String(body.name),
      slug: String(body.slug),
      description: body.description ? String(body.description) : null,
      image: body.image ? String(body.image) : null,
    })
    .where(eq(categories.id, Number(body.id)))
    .returning();
  return NextResponse.json({ category: c });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  await db.delete(categories).where(eq(categories.id, Number(id)));
  return NextResponse.json({ ok: true });
}