import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select({ id: users.id, name: users.name, email: users.email, role: users.role, createdAt: users.createdAt }).from(users);
  return NextResponse.json({ users: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const hash = await bcrypt.hash(body.password || "changeme", 10);
  const [u] = await db
    .insert(users)
    .values({ name: body.name, email: body.email, passwordHash: hash, role: body.role || "staff" })
    .returning();
  return NextResponse.json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  await db.delete(users).where(eq(users.id, Number(id)));
  return NextResponse.json({ ok: true });
}