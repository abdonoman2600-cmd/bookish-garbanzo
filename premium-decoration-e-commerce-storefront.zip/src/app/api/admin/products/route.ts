import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(products).orderBy(products.id);
  return NextResponse.json({ products: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const [p] = await db
    .insert(products)
    .values({
      name: String(body.name),
      slug: String(body.slug),
      description: body.description ? String(body.description) : null,
      price: String(body.price),
      compareAtPrice: body.compareAtPrice ? String(body.compareAtPrice) : null,
      categoryId: body.categoryId ? Number(body.categoryId) : null,
      images: Array.isArray(body.images) ? body.images : [],
      stock: body.stock ? Number(body.stock) : 0,
      featured: Boolean(body.featured),
    })
    .returning();
  return NextResponse.json({ product: p });
}

export async function PUT(req: Request) {
  const body = await req.json();
  const [p] = await db
    .update(products)
    .set({
      name: String(body.name),
      slug: String(body.slug),
      description: body.description ? String(body.description) : null,
      price: String(body.price),
      compareAtPrice: body.compareAtPrice ? String(body.compareAtPrice) : null,
      categoryId: body.categoryId ? Number(body.categoryId) : null,
      images: Array.isArray(body.images) ? body.images : [],
      stock: body.stock ? Number(body.stock) : 0,
      featured: Boolean(body.featured),
    })
    .where(eq(products.id, Number(body.id)))
    .returning();
  return NextResponse.json({ product: p });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "missing id" }, { status: 400 });
  await db.delete(products).where(eq(products.id, Number(id)));
  return NextResponse.json({ ok: true });
}