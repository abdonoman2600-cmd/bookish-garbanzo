import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(orders).orderBy(orders.createdAt);
  return NextResponse.json({ orders: rows });
}

export async function PUT(req: Request) {
  const body = await req.json();
  const [o] = await db
    .update(orders)
    .set({ status: String(body.status) })
    .where(eq(orders.id, Number(body.id)))
    .returning();
  return NextResponse.json({ order: o });
}