import { exec } from "child_process";
import { promisify } from "util";
import { NextResponse } from "next/server";

const execAsync = promisify(exec);

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const { stdout } = await execAsync(
      "pg_dump postgresql://postgres:postgres@127.0.0.1:5432/app_db"
    );
    return new NextResponse(stdout, {
      headers: {
        "Content-Type": "application/sql",
        "Content-Disposition": "attachment; filename=backup.sql",
      },
    });
  } catch (e) {
    return NextResponse.json({ error: "backup failed" }, { status: 500 });
  }
}