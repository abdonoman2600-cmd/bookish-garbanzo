import { NextResponse } from "next/server";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "rashid2024";

export async function GET(req: Request) {
  const cookie = req.headers.get("cookie") || "";
  const match = cookie.match(/admin_token=([^;]+)/);
  const token = match ? decodeURIComponent(match[1]) : null;
  return NextResponse.json({ isAdmin: token === ADMIN_PASSWORD });
}