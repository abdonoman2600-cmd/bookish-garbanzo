import { db } from "@/db";
import { pages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(pages);
  return NextResponse.json({ pages: rows });
}

export async function POST(req: Request) {
  const body = await req.json();
  const existing = await db.select().from(pages).where(eq(pages.slug, body.slug));
  if (existing.length > 0) {
    const [p] = await db
      .update(pages)
      .set({
        titleAr: body.titleAr,
        titleEn: body.titleEn,
        contentAr: body.contentAr,
        contentEn: body.contentEn,
        updatedAt: new Date(),
      })
      .where(eq(pages.slug, body.slug))
      .returning();
    return NextResponse.json({ page: p });
  }
  const [p] = await db
    .insert(pages)
    .values({
      slug: body.slug,
      titleAr: body.titleAr,
      titleEn: body.titleEn,
      contentAr: body.contentAr,
      contentEn: body.contentEn,
    })
    .returning();
  return NextResponse.json({ page: p });
}