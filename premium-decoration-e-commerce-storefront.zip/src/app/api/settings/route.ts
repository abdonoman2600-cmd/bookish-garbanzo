import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(siteSettings);
  const map: Record<string, string> = {};
  for (const r of rows) if (r.value !== null) map[r.key] = r.value;
  return NextResponse.json({ settings: map });
}