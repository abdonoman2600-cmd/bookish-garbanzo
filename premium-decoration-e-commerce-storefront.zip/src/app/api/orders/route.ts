import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      customerName,
      email,
      phone,
      address,
      city,
      notes,
      items,
      subtotal,
      shippingCost,
      taxAmount,
      total,
      paymentMethod,
    } = body;

    const cookie = req.headers.get("cookie") || "";
    const match = cookie.match(/customer_token=([^;]+)/);
    const customerId = match ? Number(match[1]) : null;

    if (!customerName || !phone || !address || !city || !items?.length) {
      return NextResponse.json({ error: "missing fields" }, { status: 400 });
    }

    const [order] = await db
      .insert(orders)
      .values({
        customerId,
        customerName: String(customerName),
        email: email ? String(email) : null,
        phone: String(phone),
        address: String(address),
        city: String(city),
        notes: notes ? String(notes) : null,
        subtotal: String(subtotal ?? total),
        shippingCost: String(shippingCost ?? 0),
        taxAmount: String(taxAmount ?? 0),
        discountAmount: "0",
        total: String(total),
        status: "new",
        paymentMethod: paymentMethod ?? "cod",
        paymentStatus: "pending",
      })
      .returning();

    await db.insert(orderItems).values(
      items.map((it: any) => ({
        orderId: order.id,
        productId: it.productId ? Number(it.productId) : null,
        productName: String(it.name),
        quantity: Number(it.quantity),
        price: String(it.price),
      }))
    );

    return NextResponse.json({ order });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
}