"use client";

import { useEffect, useState } from "react";

type Category = { id: number; name: string; slug: string; description: string | null; image: string | null };

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState({ name: "", slug: "", description: "", image: "" });
  const [editing, setEditing] = useState<Category | null>(null);

  async function load() {
    const res = await fetch("/api/admin/categories");
    const data = await res.json();
    setCategories(data.categories);
  }

  useEffect(() => {
    load();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const payload = { ...form, id: editing?.id };
    await fetch("/api/admin/categories", {
      method: editing ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setForm({ name: "", slug: "", description: "", image: "" });
    setEditing(null);
    load();
  }

  async function remove(id: number) {
    if (!confirm("حذف التصنيف؟")) return;
    await fetch(`/api/admin/categories?id=${id}`, { method: "DELETE" });
    load();
  }

  function edit(c: Category) {
    setEditing(c);
    setForm({
      name: c.name,
      slug: c.slug,
      description: c.description ?? "",
      image: c.image ?? "",
    });
  }

  async function uploadFile(file: File) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) setForm((f) => ({ ...f, image: data.url }));
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">التصنيفات</h1>
      <form onSubmit={save} className="mt-6 rounded-2xl bg-white p-6 shadow-sm">
        <h2 className="font-display text-lg text-brand">
          {editing ? "تعديل تصنيف" : "إضافة تصنيف"}
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="اسم التصنيف"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <input
            required
            value={form.slug}
            onChange={(e) => setForm({ ...form, slug: e.target.value })}
            placeholder="slug"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <input
            value={form.image}
            onChange={(e) => setForm({ ...form, image: e.target.value })}
            placeholder="رابط الصورة"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <label className="cursor-pointer rounded-xl bg-brand px-4 py-2 text-center text-sm text-cream">
            رفع صورة
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) uploadFile(f);
              }}
            />
          </label>
        </div>
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="الوصف"
          rows={2}
          className="mt-3 w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
        />
        <div className="mt-4 flex gap-2">
          <button
            type="submit"
            className="rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream"
          >
            {editing ? "حفظ" : "إضافة"}
          </button>
          {editing && (
            <button
              type="button"
              onClick={() => {
                setEditing(null);
                setForm({ name: "", slug: "", description: "", image: "" });
              }}
              className="rounded-full border border-black/10 px-6 py-2 text-sm"
            >
              إلغاء
            </button>
          )}
        </div>
      </form>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <div key={c.id} className="rounded-2xl bg-white p-4 shadow-sm">
            {c.image && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={c.image} alt={c.name} className="h-32 w-full rounded-xl object-cover" />
            )}
            <h3 className="mt-2 font-semibold text-brand">{c.name}</h3>
            <p className="text-xs text-muted">{c.slug}</p>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => edit(c)}
                className="rounded-lg bg-sand px-3 py-1 text-xs"
              >
                تعديل
              </button>
              <button
                onClick={() => remove(c.id)}
                className="rounded-lg bg-red-50 px-3 py-1 text-xs text-red-600"
              >
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}