"use client";

import { useEffect, useState } from "react";

export default function AdminPagesPage() {
  const [slug, setSlug] = useState("about");
  const [form, setForm] = useState({ titleAr: "", titleEn: "", contentAr: "", contentEn: "" });
  const [faqs, setFaqs] = useState<any[]>([]);
  const [fForm, setFForm] = useState({ questionAr: "", answerAr: "", sortOrder: 0 });
  const [msg, setMsg] = useState("");

  async function loadPage(s: string) {
    const res = await fetch("/api/admin/pages");
    const data = await res.json();
    const p = (data.pages ?? []).find((x: any) => x.slug === s);
    setForm({
      titleAr: p?.titleAr ?? "",
      titleEn: p?.titleEn ?? "",
      contentAr: p?.contentAr ?? "",
      contentEn: p?.contentEn ?? "",
    });
  }

  async function loadFaqs() {
    const res = await fetch("/api/admin/faqs");
    const data = await res.json();
    setFaqs(data.faqs ?? []);
  }

  useEffect(() => {
    loadPage(slug);
    loadFaqs();
  }, [slug]);

  async function savePage(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/pages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug, ...form }),
    });
    setMsg("تم حفظ الصفحة");
  }

  async function saveFaq(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/faqs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(fForm),
    });
    setFForm({ questionAr: "", answerAr: "", sortOrder: 0 });
    loadFaqs();
  }

  async function removeFaq(id: number) {
    await fetch(`/api/admin/faqs?id=${id}`, { method: "DELETE" });
    loadFaqs();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">الصفحات والأسئلة</h1>

      <div className="mt-4 flex gap-2">
        {["about", "contact"].map((s) => (
          <button
            key={s}
            onClick={() => setSlug(s)}
            className={`rounded-full px-4 py-1 text-sm ${slug === s ? "bg-brand text-cream" : "bg-sand"}`}
          >
            {s === "about" ? "من نحن" : "اتصل بنا"}
          </button>
        ))}
      </div>

      <form onSubmit={savePage} className="mt-6 rounded-2xl bg-white p-6 shadow-sm">
        <h2 className="font-display text-lg text-brand">تعديل صفحة</h2>
        <input
          value={form.titleAr}
          onChange={(e) => setForm({ ...form, titleAr: e.target.value })}
          placeholder="العنوان (عربي)"
          className="mt-3 w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
        />
        <textarea
          value={form.contentAr}
          onChange={(e) => setForm({ ...form, contentAr: e.target.value })}
          placeholder="المحتوى (عربي)"
          rows={6}
          className="mt-3 w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
        />
        <button type="submit" className="mt-3 rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream">
          حفظ
        </button>
        {msg && <span className="ml-3 text-sm text-green-600">{msg}</span>}
      </form>

      <div className="mt-8 rounded-2xl bg-white p-6 shadow-sm">
        <h2 className="font-display text-lg text-brand">الأسئلة الشائعة</h2>
        <form onSubmit={saveFaq} className="mt-4 space-y-3">
          <input
            value={fForm.questionAr}
            onChange={(e) => setFForm({ ...fForm, questionAr: e.target.value })}
            placeholder="السؤال"
            className="w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <textarea
            value={fForm.answerAr}
            onChange={(e) => setFForm({ ...fForm, answerAr: e.target.value })}
            placeholder="الإجابة"
            rows={3}
            className="w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <button type="submit" className="rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream">
            إضافة سؤال
          </button>
        </form>
        <ul className="mt-4 space-y-2">
          {faqs.map((f) => (
            <li key={f.id} className="flex items-center justify-between rounded-xl bg-sand p-3 text-sm">
              <span>{f.questionAr}</span>
              <button onClick={() => removeFaq(f.id)} className="text-red-600">
                حذف
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}