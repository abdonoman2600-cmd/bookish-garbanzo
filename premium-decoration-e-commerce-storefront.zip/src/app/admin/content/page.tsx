"use client";

import { useEffect, useState } from "react";
import { DEFAULT_SETTINGS } from "@/lib/settings-defaults";

export default function AdminContentPage() {
  const [form, setForm] = useState<Record<string, string>>({ ...DEFAULT_SETTINGS });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((data) => {
        const map: Record<string, string> = { ...DEFAULT_SETTINGS };
        for (const r of data.settings ?? []) {
          if (r.value !== null) map[r.key] = r.value;
        }
        setForm(map);
      });
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMsg("");
    await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    setMsg("تم الحفظ بنجاح");
  }

  async function uploadFile(file: File, field: string) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) setForm((f) => ({ ...f, [field]: data.url }));
  }

  const fields: { key: string; label: string; type?: string }[] = [
    { key: "brand_color", label: "لون العلامة (Brand)", type: "color" },
    { key: "accent_color", label: "لون التمييز (Accent)", type: "color" },
    { key: "store_name", label: "اسم المتجر" },
    { key: "hero_title", label: "عنوان Hero" },
    { key: "hero_subtitle", label: "نص Hero" },
    { key: "hero_cta", label: "نص زر Hero" },
    { key: "promo_title", label: "عنوان العرض" },
    { key: "promo_text", label: "نص العرض" },
    { key: "promo_code", label: "كود الخصم" },
    { key: "footer_phone", label: "رقم الجوال (Footer)" },
    { key: "footer_email", label: "البريد (Footer)" },
    { key: "footer_address", label: "العنوان (Footer)" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">محتوى المتجر</h1>
      <p className="mt-1 text-sm text-muted">
        تحكم بعناوين المتجر، الصور، النصوص، والعرض الترويجي.
      </p>

      <form onSubmit={save} className="mt-6 space-y-6">
        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="font-display text-lg text-brand">النصوص</h2>
          <div className="mt-4 grid gap-3">
            {fields.map((f) => (
              <div key={f.key}>
                <label className="mb-1 block text-xs text-muted">{f.label}</label>
                {f.key.includes("subtitle") || f.key.includes("text") ? (
                  <textarea
                    value={form[f.key] ?? ""}
                    onChange={(e) =>
                      setForm({ ...form, [f.key]: e.target.value })
                    }
                    rows={3}
                    className="w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
                  />
                ) : (
                  <input
                    type={f.type === "color" ? "color" : "text"}
                    value={form[f.key] ?? ""}
                    onChange={(e) =>
                      setForm({ ...form, [f.key]: e.target.value })
                    }
                    className="w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <h2 className="font-display text-lg text-brand">صور Hero</h2>
          <div className="mt-4">
            {form.hero_image && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={form.hero_image}
                alt="hero"
                className="h-40 w-full rounded-xl object-cover"
              />
            )}
            <div className="mt-3 flex gap-2">
              <input
                value={form.hero_image ?? ""}
                onChange={(e) => setForm({ ...form, hero_image: e.target.value })}
                placeholder="رابط صورة Hero"
                className="flex-1 rounded-xl border border-black/10 px-4 py-2 text-sm"
              />
              <label className="cursor-pointer rounded-xl bg-brand px-4 py-2 text-sm text-cream">
                رفع
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadFile(f, "hero_image");
                  }}
                />
              </label>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream"
          >
            {saving ? "جارٍ الحفظ..." : "حفظ التغييرات"}
          </button>
          {msg && <span className="text-sm text-green-600">{msg}</span>}
        </div>
      </form>
    </div>
  );
}