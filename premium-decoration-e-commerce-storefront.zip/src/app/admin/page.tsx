import { db } from "@/db";
import { products, categories, orders } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const [p] = await db.select({ c: sql<number>`count(*)::int` }).from(products);
  const [c] = await db.select({ c: sql<number>`count(*)::int` }).from(categories);
  const [o] = await db.select({ c: sql<number>`count(*)::int` }).from(orders);
  const recentOrders = await db.select().from(orders).orderBy(orders.createdAt).limit(5);

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">لوحة التحكم</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-muted">المنتجات</p>
          <p className="mt-1 text-3xl font-bold text-brand">{p.c}</p>
        </div>
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-muted">التصنيفات</p>
          <p className="mt-1 text-3xl font-bold text-brand">{c.c}</p>
        </div>
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-muted">الطلبات</p>
          <p className="mt-1 text-3xl font-bold text-brand">{o.c}</p>
        </div>
      </div>
      <h2 className="mt-8 font-display text-xl text-brand">آخر الطلبات</h2>
      <div className="mt-3 overflow-x-auto rounded-2xl bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="p-3 text-right">#</th>
              <th className="p-3 text-right">العميل</th>
              <th className="p-3 text-right">المدينة</th>
              <th className="p-3 text-right">المجموع</th>
              <th className="p-3 text-right">الحالة</th>
            </tr>
          </thead>
          <tbody>
            {recentOrders.map((o) => (
              <tr key={o.id} className="border-t border-black/5">
                <td className="p-3">{o.id}</td>
                <td className="p-3">{o.customerName}</td>
                <td className="p-3">{o.city}</td>
                <td className="p-3">{Number(o.total).toFixed(2)} ر.س</td>
                <td className="p-3">{o.status}</td>
              </tr>
            ))}
            {recentOrders.length === 0 && (
              <tr>
                <td colSpan={5} className="p-6 text-center text-muted">
                  لا توجد طلبات بعد
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}