import Link from "next/link";
import AdminLogout from "@/components/AdminLogout";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-sand/40">
      <header className="border-b border-black/5 bg-brand text-cream">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <span className="font-display text-xl">لوحة تحكم رشيد</span>
          <AdminLogout />
        </div>
      </header>
      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 sm:px-6">
        <aside className="hidden w-48 flex-shrink-0 md:block">
          <nav className="space-y-1 rounded-2xl bg-white p-3 shadow-sm">
            <Link href="/admin" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              الرئيسية
            </Link>
            <Link href="/admin/products" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              المنتجات
            </Link>
            <Link href="/admin/categories" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              التصنيفات
            </Link>
            <Link href="/admin/content" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              محتوى المتجر
            </Link>
            <Link href="/admin/media" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              مكتبة الصور
            </Link>
            <Link href="/admin/pages" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              الصفحات
            </Link>
            <Link href="/admin/orders" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              الطلبات
            </Link>
            <Link href="/admin/reports" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              التقارير
            </Link>
            <Link href="/admin/staff" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              الموظفون
            </Link>
            <Link href="/admin/backup" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              النسخ الاحتياطي
            </Link>
            <Link href="/" className="block rounded-xl px-3 py-2 text-sm hover:bg-sand">
              عرض المتجر
            </Link>
          </nav>
        </aside>
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}