"use client";

import { useEffect, useState } from "react";

export default function AdminMediaPage() {
  const [files, setFiles] = useState<string[]>([]);

  async function load() {
    const res = await fetch("/api/admin/media");
    const data = await res.json();
    setFiles(data.files ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function upload(file: File) {
    const fd = new FormData();
    fd.append("file", file);
    await fetch("/api/admin/upload", { method: "POST", body: fd });
    load();
  }

  async function remove(url: string) {
    if (!confirm("حذف الصورة؟")) return;
    await fetch(`/api/admin/media?url=${encodeURIComponent(url)}`, {
      method: "DELETE",
    });
    load();
  }

  function copy(url: string) {
    navigator.clipboard.writeText(window.location.origin + url);
    alert("تم نسخ الرابط");
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">مكتبة الصور</h1>
      <p className="mt-1 text-sm text-muted">
        ارفع، انسخ روابط، أو احذف الصور. استخدم الروابط في المنتجات والتصنيفات.
      </p>

      <div className="mt-6">
        <label className="cursor-pointer rounded-full bg-brand px-5 py-2 text-sm font-bold text-cream">
          رفع صور
          <input
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              const fs = e.target.files;
              if (fs) Array.from(fs).forEach(upload);
            }}
          />
        </label>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {files.map((f) => (
          <div key={f} className="overflow-hidden rounded-2xl bg-white shadow-sm">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={f} alt="" className="h-32 w-full object-cover" />
            <div className="flex gap-1 p-2">
              <button
                onClick={() => copy(f)}
                className="flex-1 rounded-lg bg-sand px-2 py-1 text-xs"
              >
                نسخ
              </button>
              <button
                onClick={() => remove(f)}
                className="rounded-lg bg-red-50 px-2 py-1 text-xs text-red-600"
              >
                حذف
              </button>
            </div>
          </div>
        ))}
        {files.length === 0 && (
          <p className="col-span-full text-center text-muted">
            لا توجد صور مرفوعة.
          </p>
        )}
      </div>
    </div>
  );
}