"use client";

import { useEffect, useState } from "react";

type Category = { id: number; name: string; slug: string };
type Product = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  price: string;
  compareAtPrice: string | null;
  categoryId: number | null;
  images: string[] | null;
  stock: number | null;
  featured: boolean | null;
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState<any>({
    name: "",
    slug: "",
    description: "",
    price: "",
    compareAtPrice: "",
    categoryId: "",
    images: [] as string[],
    stock: 0,
    featured: false,
  });
  const [imageUrl, setImageUrl] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    const [pr, cr] = await Promise.all([
      fetch("/api/admin/products").then((r) => r.json()),
      fetch("/api/admin/categories").then((r) => r.json()),
    ]);
    setProducts(pr.products);
    setCategories(cr.categories);
  }

  useEffect(() => {
    load();
  }, []);

  function resetForm() {
    setEditing(null);
    setForm({
      name: "",
      slug: "",
      description: "",
      price: "",
      compareAtPrice: "",
      categoryId: "",
      images: [],
      stock: 0,
      featured: false,
    });
    setImageUrl("");
  }

  function edit(p: Product) {
    setEditing(p);
    setForm({
      name: p.name,
      slug: p.slug,
      description: p.description ?? "",
      price: p.price,
      compareAtPrice: p.compareAtPrice ?? "",
      categoryId: p.categoryId ?? "",
      images: p.images ?? [],
      stock: p.stock ?? 0,
      featured: !!p.featured,
    });
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const payload = {
      ...form,
      id: editing?.id,
      categoryId: form.categoryId ? Number(form.categoryId) : null,
      price: form.price,
      compareAtPrice: form.compareAtPrice || null,
      stock: Number(form.stock) || 0,
    };
    const url = "/api/admin/products";
    const method = editing ? "PUT" : "POST";
    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSaving(false);
    resetForm();
    load();
  }

  async function remove(id: number) {
    if (!confirm("حذف المنتج؟")) return;
    await fetch(`/api/admin/products?id=${id}`, { method: "DELETE" });
    load();
  }

  async function uploadFile(file: File) {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) setForm((f: any) => ({ ...f, images: [...f.images, data.url] }));
  }

  function addImageUrl() {
    if (!imageUrl.trim()) return;
    setForm((f: any) => ({ ...f, images: [...f.images, imageUrl.trim()] }));
    setImageUrl("");
  }

  function removeImage(idx: number) {
    setForm((f: any) => ({
      ...f,
      images: f.images.filter((_: any, i: number) => i !== idx),
    }));
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">المنتجات</h1>

      <form
        onSubmit={save}
        className="mt-6 rounded-2xl bg-white p-6 shadow-sm"
      >
        <h2 className="font-display text-lg text-brand">
          {editing ? "تعديل منتج" : "إضافة منتج جديد"}
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="اسم المنتج"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <input
            required
            value={form.slug}
            onChange={(e) => setForm({ ...form, slug: e.target.value })}
            placeholder="slug (مثال: gypsum-board-12mm)"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <input
            required
            type="number"
            step="0.01"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })}
            placeholder="السعر"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <input
            type="number"
            step="0.01"
            value={form.compareAtPrice}
            onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value })}
            placeholder="السعر قبل الخصم (اختياري)"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
          <select
            value={form.categoryId}
            onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          >
            <option value="">بدون تصنيف</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <input
            type="number"
            value={form.stock}
            onChange={(e) => setForm({ ...form, stock: e.target.value })}
            placeholder="المخزون"
            className="rounded-xl border border-black/10 px-4 py-2 text-sm"
          />
        </div>
        <textarea
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="الوصف"
          rows={3}
          className="mt-3 w-full rounded-xl border border-black/10 px-4 py-2 text-sm"
        />
        <label className="mt-3 flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) => setForm({ ...form, featured: e.target.checked })}
          />
          منتج مميز
        </label>

        {/* Images */}
        <div className="mt-4">
          <p className="text-sm font-semibold text-brand">الصور</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {form.images.map((img: string, idx: number) => (
              <div key={idx} className="relative h-20 w-20 overflow-hidden rounded-xl bg-sand">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={img} alt="" className="h-full w-full object-cover" />
                <button
                  type="button"
                  onClick={() => removeImage(idx)}
                  className="absolute right-1 top-1 rounded-full bg-white/80 px-1 text-xs"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <input
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="رابط صورة (URL)"
              className="flex-1 rounded-xl border border-black/10 px-4 py-2 text-sm"
            />
            <button
              type="button"
              onClick={addImageUrl}
              className="rounded-xl bg-sand px-4 py-2 text-sm"
            >
              إضافة رابط
            </button>
            <label className="cursor-pointer rounded-xl bg-brand px-4 py-2 text-sm text-cream">
              رفع ملف
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) uploadFile(f);
                }}
              />
            </label>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            type="submit"
            disabled={saving}
            className="rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream"
          >
            {saving ? "جارٍ الحفظ..." : editing ? "حفظ التعديلات" : "إضافة"}
          </button>
          {editing && (
            <button
              type="button"
              onClick={resetForm}
              className="rounded-full border border-black/10 px-6 py-2 text-sm"
            >
              إلغاء
            </button>
          )}
        </div>
      </form>

      <div className="mt-8 overflow-x-auto rounded-2xl bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="p-3 text-right">الصورة</th>
              <th className="p-3 text-right">الاسم</th>
              <th className="p-3 text-right">السعر</th>
              <th className="p-3 text-right">المخزون</th>
              <th className="p-3 text-right">مميز</th>
              <th className="p-3 text-right">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-t border-black/5">
                <td className="p-3">
                  {p.images?.[0] ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={p.images[0]}
                      alt=""
                      className="h-12 w-12 rounded-lg object-cover"
                    />
                  ) : (
                    "—"
                  )}
                </td>
                <td className="p-3">{p.name}</td>
                <td className="p-3">{Number(p.price).toFixed(2)}</td>
                <td className="p-3">{p.stock}</td>
                <td className="p-3">{p.featured ? "★" : ""}</td>
                <td className="p-3">
                  <div className="flex gap-2">
                    <button
                      onClick={() => edit(p)}
                      className="rounded-lg bg-sand px-3 py-1 text-xs"
                    >
                      تعديل
                    </button>
                    <button
                      onClick={() => remove(p.id)}
                      className="rounded-lg bg-red-50 px-3 py-1 text-xs text-red-600"
                    >
                      حذف
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}