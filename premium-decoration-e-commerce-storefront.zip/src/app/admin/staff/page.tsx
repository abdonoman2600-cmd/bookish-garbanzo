"use client";

import { useEffect, useState } from "react";

export default function AdminStaffPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "staff" });

  async function load() {
    const res = await fetch("/api/admin/staff");
    const data = await res.json();
    setUsers(data.users ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/admin/staff", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ name: "", email: "", password: "", role: "staff" });
    load();
  }

  async function remove(id: number) {
    if (!confirm("حذف المستخدم؟")) return;
    await fetch(`/api/admin/staff?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">الموظفون والمستخدمون</h1>
      <form onSubmit={add} className="mt-6 rounded-2xl bg-white p-6 shadow-sm">
        <div className="grid gap-3 sm:grid-cols-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="الاسم" className="rounded-xl border border-black/10 px-4 py-2 text-sm" />
          <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="البريد" className="rounded-xl border border-black/10 px-4 py-2 text-sm" />
          <input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="كلمة المرور" className="rounded-xl border border-black/10 px-4 py-2 text-sm" />
          <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="rounded-xl border border-black/10 px-4 py-2 text-sm">
            <option value="staff">موظف</option>
            <option value="owner">مالك</option>
            <option value="customer">عميل</option>
          </select>
        </div>
        <button type="submit" className="mt-3 rounded-full bg-brand px-6 py-2 text-sm font-bold text-cream">إضافة</button>
      </form>
      <div className="mt-6 overflow-x-auto rounded-2xl bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="p-3 text-right">الاسم</th>
              <th className="p-3 text-right">البريد</th>
              <th className="p-3 text-right">الدور</th>
              <th className="p-3 text-right">إجراء</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-black/5">
                <td className="p-3">{u.name}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3">{u.role}</td>
                <td className="p-3">
                  <button onClick={() => remove(u.id)} className="rounded-lg bg-red-50 px-3 py-1 text-xs text-red-600">حذف</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}