export default function BackupPage() {
  return (
    <div>
      <h1 className="font-display text-2xl text-brand">النسخ الاحتياطي</h1>
      <p className="mt-2 text-sm text-muted">
        تنزيل نسخة احتياطية من قاعدة البيانات (SQL).
      </p>
      <a
        href="/api/admin/backup"
        className="mt-6 inline-block rounded-full bg-brand px-6 py-3 text-sm font-bold text-cream"
      >
        تنزيل النسخة الاحتياطية
      </a>
    </div>
  );
}