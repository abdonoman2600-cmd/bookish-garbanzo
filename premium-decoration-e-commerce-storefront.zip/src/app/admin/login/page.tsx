"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    setLoading(false);
    if (res.ok) {
      router.push("/admin");
      router.refresh();
    } else {
      setError("كلمة المرور غير صحيحة");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4">
      <form
        onSubmit={submit}
        className="w-full max-w-sm rounded-3xl bg-white p-8 shadow-lg"
      >
        <h1 className="font-display text-2xl text-brand">لوحة التحكم</h1>
        <p className="mt-1 text-sm text-muted">رشيد — دخول المدير</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="كلمة المرور"
          className="mt-6 w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        />
        {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="mt-4 w-full rounded-full bg-brand py-3 text-sm font-bold text-cream"
        >
          {loading ? "جارٍ الدخول..." : "دخول"}
        </button>
        <p className="mt-4 text-xs text-muted">
          كلمة المرور الافتراضية: rashid2024 (غيّرها عبر ADMIN_PASSWORD)
        </p>
      </form>
    </div>
  );
}