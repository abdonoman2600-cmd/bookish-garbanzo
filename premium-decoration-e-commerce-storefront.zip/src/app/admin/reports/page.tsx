import { db } from "@/db";
import { orders, orderItems, products } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const [totals] = await db
    .select({
      count: sql<number>`count(*)::int`,
      revenue: sql<string>`coalesce(sum(total),0)`,
    })
    .from(orders);
  const byStatus = await db
    .select({ status: orders.status, c: sql<number>`count(*)::int` })
    .from(orders)
    .groupBy(orders.status);
  const topProducts = await db
    .select({
      name: orderItems.productName,
      qty: sql<number>`sum(${orderItems.quantity})::int`,
    })
    .from(orderItems)
    .groupBy(orderItems.productName)
    .orderBy(sql`sum(${orderItems.quantity}) desc`)
    .limit(5);

  return (
    <div>
      <h1 className="font-display text-2xl text-brand">التقارير</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-muted">عدد الطلبات</p>
          <p className="mt-1 text-3xl font-bold text-brand">{totals.count}</p>
        </div>
        <div className="rounded-2xl bg-white p-5 shadow-sm">
          <p className="text-sm text-muted">إجمالي المبيعات</p>
          <p className="mt-1 text-3xl font-bold text-brand">
            {Number(totals.revenue).toFixed(2)} ر.س
          </p>
        </div>
      </div>
      <h2 className="mt-8 font-display text-xl text-brand">حسب الحالة</h2>
      <div className="mt-3 rounded-2xl bg-white p-5 shadow-sm">
        {byStatus.map((s) => (
          <div key={s.status} className="flex justify-between border-b border-black/5 py-2 text-sm">
            <span>{s.status}</span>
            <span className="font-bold">{s.c}</span>
          </div>
        ))}
      </div>
      <h2 className="mt-8 font-display text-xl text-brand">الأكثر مبيعًا</h2>
      <div className="mt-3 rounded-2xl bg-white p-5 shadow-sm">
        {topProducts.map((p) => (
          <div key={p.name} className="flex justify-between border-b border-black/5 py-2 text-sm">
            <span>{p.name}</span>
            <span className="font-bold">{p.qty}</span>
          </div>
        ))}
        {topProducts.length === 0 && <p className="text-muted">لا توجد بيانات.</p>}
      </div>
    </div>
  );
}