import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeed } from "@/db/seed";
import { notFound } from "next/navigation";
import ProductDetailClient from "@/components/ProductDetailClient";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  await ensureSeed();
  const { slug } = await params;
  const [product] = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug));
  if (!product) notFound();

  const [category] = product.categoryId
    ? await db
        .select()
        .from(categories)
        .where(eq(categories.id, product.categoryId))
    : [null];

  const productReviews = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, product.id))
    .orderBy(reviews.createdAt);

  const related = await db
    .select()
    .from(products)
    .where(eq(products.categoryId, product.categoryId ?? 0))
    .limit(4);

  return (
    <ProductDetailClient
      product={product}
      category={category}
      reviews={productReviews}
      related={related.filter((r) => r.id !== product.id).slice(0, 4)}
    />
  );
}