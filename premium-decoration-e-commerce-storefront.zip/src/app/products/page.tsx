import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import ProductsClient from "@/components/ProductsClient";

export const dynamic = "force-dynamic";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; featured?: string; q?: string }>;
}) {
  await ensureSeed();
  const sp = await searchParams;
  const cats = await db.select().from(categories);
  const prods = await db.select().from(products);
  return (
    <ProductsClient
      categories={cats}
      products={prods}
      initialCategory={sp.category ?? ""}
      initialFeatured={sp.featured === "1"}
      initialQuery={sp.q ?? ""}
    />
  );
}