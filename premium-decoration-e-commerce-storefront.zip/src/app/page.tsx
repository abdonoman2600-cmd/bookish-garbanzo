import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { ensureSeed } from "@/db/seed";
import { getSettings } from "@/lib/settings";
import Link from "next/link";
import Image from "next/image";
import ProductCard from "@/components/ProductCard";
import HeroSection from "@/components/HeroSection";
import PromoBanner from "@/components/PromoBanner";
import CategoryCard from "@/components/CategoryCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeed();
  const settings = await getSettings();
  const cats = await db.select().from(categories);
  const featured = await db
    .select()
    .from(products)
    .where(eq(products.featured, true))
    .orderBy(desc(products.createdAt))
    .limit(8);

  const heroImg = settings.hero_image;

  return (
    <div>
      <HeroSection initial={settings} />

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-accent">
              التصنيفات
            </p>
            <h2 className="mt-2 font-display text-3xl text-brand">
              اكتشف مجموعاتنا
            </h2>
          </div>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {cats.map((c) => (
            <CategoryCard key={c.id} category={c} />
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="bg-sand/60 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-accent">
                مختارات
              </p>
              <h2 className="mt-2 font-display text-3xl text-brand">
                منتجات مميزة
              </h2>
            </div>
            <Link
              href="/products"
              className="text-sm font-semibold text-brand hover:text-accent"
            >
              عرض الكل ←
            </Link>
          </div>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      <PromoBanner initial={settings} />
    </div>
  );
}