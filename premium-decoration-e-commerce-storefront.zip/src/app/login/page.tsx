"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useI18n } from "@/lib/i18n";

export default function LoginPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { t } = useI18n();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const url = mode === "login" ? "/api/auth/login" : "/api/auth/register";
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (res.ok) {
      router.push("/account");
      router.refresh();
    } else {
      const d = await res.json();
      setError(d.error || "error");
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className="rounded-3xl bg-white p-8 shadow-sm">
        <h1 className="font-display text-2xl text-brand">
          {mode === "login" ? t("login") : t("register")}
        </h1>
        <div className="mt-4 flex gap-2">
          <button
            onClick={() => setMode("login")}
            className={`rounded-full px-4 py-1 text-sm ${mode === "login" ? "bg-brand text-cream" : "bg-sand"}`}
          >
            {t("login")}
          </button>
          <button
            onClick={() => setMode("register")}
            className={`rounded-full px-4 py-1 text-sm ${mode === "register" ? "bg-brand text-cream" : "bg-sand"}`}
          >
            {t("register")}
          </button>
        </div>
        <form onSubmit={submit} className="mt-6 space-y-3">
          {mode === "register" && (
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder={t("name")}
              className="w-full rounded-full border border-black/10 px-4 py-2 text-sm"
            />
          )}
          <input
            required
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="Email"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm"
          />
          <input
            required
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            placeholder="Password"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm"
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-brand py-3 text-sm font-bold text-cream"
          >
            {loading ? "..." : mode === "login" ? t("login") : t("register")}
          </button>
        </form>
      </div>
    </div>
  );
}