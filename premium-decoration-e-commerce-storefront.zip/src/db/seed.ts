import { db } from "@/db";
import { categories, products, reviews } from "@/db/schema";
import { sql } from "drizzle-orm";

const IMG = {
  a: "https://images.pexels.com/photos/8082226/pexels-photo-8082226.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  b: "https://images.pexels.com/photos/8135502/pexels-photo-8135502.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  c: "https://images.pexels.com/photos/39378920/pexels-photo-39378920.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  d: "https://images.pexels.com/photos/9543230/pexels-photo-9543230.png?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  e: "https://images.pexels.com/photos/17404697/pexels-photo-17404697.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  f: "https://images.pexels.com/photos/7166926/pexels-photo-7166926.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  g: "https://images.pexels.com/photos/35139106/pexels-photo-35139106.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  h: "https://images.pexels.com/photos/6238608/pexels-photo-6238608.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  i: "https://images.pexels.com/photos/37172472/pexels-photo-37172472.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  j: "https://images.pexels.com/photos/11449320/pexels-photo-11449320.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  k: "https://images.pexels.com/photos/8082193/pexels-photo-8082193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  l: "https://images.pexels.com/photos/6908566/pexels-photo-6908566.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  try {
    const res = await db.execute(sql`select count(*)::int as c from products`);
    const count = (res as any).rows?.[0]?.c ?? 0;
    if (count > 0) {
      seeded = true;
      return;
    }
  } catch {
    // table may not exist yet; ignore
    return;
  }

  const cats = await db
    .insert(categories)
    .values([
      {
        name: "جبسن بورد",
        slug: "gypsum-board",
        description: "ألواح جبسن بورد بجودة عالية لجميع الاستخدامات",
        image: IMG.d,
      },
      {
        name: "ديكور جداري",
        slug: "wall-decor",
        description: "ألواح وپانل جدارية لتحويل مساحاتك",
        image: IMG.j,
      },
      {
        name: "أسقف مستعارة",
        slug: "false-ceilings",
        description: "أسقف مستعارة وكوفات بإضاءة مخفية",
        image: IMG.g,
      },
      {
        name: "إضاءة ديكور",
        slug: "decor-lighting",
        description: "إضاءات LED وثريات ديكور",
        image: IMG.i,
      },
      {
        name: "أدوات وملحقات",
        slug: "tools-accessories",
        description: "أدوات ومواد تثبيت وتشطيب",
        image: IMG.l,
      },
    ])
    .returning();

  const catId = (slug: string) =>
    cats.find((c) => c.slug === slug)!.id;

  const prodRows = await db
    .insert(products)
    .values([
      {
        name: "لوح جبسن بورد قياسي 12mm",
        slug: "gypsum-board-standard-12mm",
        description:
          "لوح جبسن بورد قياسي بسماكة 12mm، مناسب للأسقف والجدران الداخلية. سطح أملس سهل التشطيب.",
        price: "45.00",
        compareAtPrice: "55.00",
        categoryId: catId("gypsum-board"),
        images: [IMG.d, IMG.e],
        stock: 240,
        featured: true,
      },
      {
        name: "لوح جبسن بورد مقاوم للرطوبة 12mm",
        slug: "gypsum-board-moisture-12mm",
        description:
          "لوح جبسن بورد مقاوم للرطوبة، مثالي للمطابخ والحمامات. لون أخضر مميز.",
        price: "62.00",
        compareAtPrice: "75.00",
        categoryId: catId("gypsum-board"),
        images: [IMG.e, IMG.h],
        stock: 180,
        featured: false,
      },
      {
        name: "لوح جبسن بورد مقاوم للحريق 15mm",
        slug: "gypsum-board-fire-15mm",
        description:
          "لوح جبسن بورد مقاوم للحريق بسماكة 15mm، للاستخدامات التجارية والصناعية.",
        price: "78.00",
        categoryId: catId("gypsum-board"),
        images: [IMG.h],
        stock: 120,
        featured: false,
      },
      {
        name: "ألواح جدارية 3D - نمط هندسي",
        slug: "wall-panels-3d-geometric",
        description:
          "ألواح جدارية ثلاثية الأبعاد بنمط هندسي عصري، تضيف عمقاً وشخصية لأي مساحة.",
        price: "189.00",
        compareAtPrice: "230.00",
        categoryId: catId("wall-decor"),
        images: [IMG.j, IMG.k],
        stock: 60,
        featured: true,
      },
      {
        name: "پانل خشبي جداري - بلوط",
        slug: "wood-wall-panel-oak",
        description:
          "پانل جداري خشبي بتشطيب بلوط، دفء طبيعي وأناقة لغرف المعيشة والمكاتب.",
        price: "245.00",
        categoryId: catId("wall-decor"),
        images: [IMG.l, IMG.a],
        stock: 45,
        featured: true,
      },
      {
        name: "جدارية إسلامية - خط عربي",
        slug: "islamic-wall-art-calligraphy",
        description:
          "جدارية إسلامية بخط عربي كلاسيكي، لمسة روحية وأصالة في الديكور.",
        price: "320.00",
        compareAtPrice: "390.00",
        categoryId: catId("wall-decor"),
        images: [IMG.c, IMG.d],
        stock: 30,
        featured: true,
      },
      {
        name: "سقف مستعار - مربعات 60x60",
        slug: "false-ceiling-tiles-60x60",
        description:
          "سقف مستعار بمربعات 60x60cm، سهل التركيب والصيانة، مثالي للمكاتب والتجزئة.",
        price: "95.00",
        categoryId: catId("false-ceilings"),
        images: [IMG.g, IMG.h],
        stock: 150,
        featured: false,
      },
      {
        name: "سقف مستعار - شرائح ألمنيوم",
        slug: "false-ceiling-aluminum-strips",
        description:
          "سقف مستعار بشرائح ألمنيوم عصرية، مقاوم للرطوبة ومناسب للمساحات التجارية.",
        price: "140.00",
        compareAtPrice: "165.00",
        categoryId: catId("false-ceilings"),
        images: [IMG.h, IMG.i],
        stock: 90,
        featured: false,
      },
      {
        name: "سقف كوف - إضاءة مخفية",
        slug: "cove-ceiling-hidden-lighting",
        description:
          "سقف كوف مع إضاءة مخفية (LED)، تصميم فاخر يمنح الغرفة إضاءة ناعمة وأناقة.",
        price: "450.00",
        compareAtPrice: "520.00",
        categoryId: catId("false-ceilings"),
        images: [IMG.g, IMG.i],
        stock: 25,
        featured: true,
      },
      {
        name: "شريط LED RGB - 5 متر",
        slug: "led-strip-rgb-5m",
        description:
          "شريط LED RGB بطول 5 أمتار مع وحدة تحكم، 16 مليون لون ومتعدد التأثيرات.",
        price: "89.00",
        categoryId: catId("decor-lighting"),
        images: [IMG.g, IMG.f],
        stock: 200,
        featured: false,
      },
      {
        name: "إضاءة كوف - Warm White",
        slug: "cove-lighting-warm-white",
        description:
          "إضاءة كوف Warm White (3000K) ناعمة، مثالية لغرف النوم والمعيشة.",
        price: "120.00",
        categoryId: catId("decor-lighting"),
        images: [IMG.i, IMG.g],
        stock: 160,
        featured: false,
      },
      {
        name: "ثريا ديكور - ذهبية",
        slug: "chandelier-decor-gold",
        description:
          "ثريا ديكور ذهبية بتصميم كلاسيكي عصري، نقطة محورية لأي غرفة.",
        price: "680.00",
        compareAtPrice: "790.00",
        categoryId: catId("decor-lighting"),
        images: [IMG.e, IMG.b],
        stock: 15,
        featured: true,
      },
      {
        name: "ملقط جبسن بورد",
        slug: "gypsum-board-clamp",
        description: "ملقط متخصص لحمل وتثبيت ألواح جبسن بورد بسهولة وأمان.",
        price: "35.00",
        categoryId: catId("tools-accessories"),
        images: [IMG.l],
        stock: 80,
        featured: false,
      },
      {
        name: "مسامير جبسن بورد 1000 قطعة",
        slug: "gypsum-screws-1000",
        description: "مسامير جبسن بورد (Fine Thread) 1000 قطعة، مقاومة للصدأ.",
        price: "28.00",
        categoryId: catId("tools-accessories"),
        images: [IMG.l, IMG.a],
        stock: 300,
        featured: false,
      },
      {
        name: "معجون جبسن بورد 25kg",
        slug: "joint-compound-25kg",
        description: "معجون جبسن بورد (All-Purpose) 25kg، تشطيب ناعم وسهل الصنفرة.",
        price: "55.00",
        compareAtPrice: "65.00",
        categoryId: catId("tools-accessories"),
        images: [IMG.a],
        stock: 110,
        featured: false,
      },
      {
        name: "شريط ورق تقوية",
        slug: "paper-tape-reinforcement",
        description: "شريط ورق تقوية للدرزات، يمنع التشقق ويعزز المتانة.",
        price: "18.00",
        categoryId: catId("tools-accessories"),
        images: [IMG.a, IMG.l],
        stock: 500,
        featured: false,
      },
    ])
    .returning();

  const reviewData = [
    { author: "أحمد السبيعي", rating: 5, comment: "جودة ممتازة وتوصيل سريع. سأكرر الطلب." },
    { author: "فهد القحطاني", rating: 4, comment: "منتج جيد، التغليف محكم." },
    { author: "نورة العتيبي", rating: 5, comment: "الألواح ممتازة وسهلة التركيب." },
    { author: "خالد المطيري", rating: 4, comment: "سعر مناسب مقارنة بالسوق." },
    { author: "سارة الدوسري", rating: 5, comment: "الثريا فاخرة جداً، تجاوزت التوقعات." },
    { author: "عبدالله الشمري", rating: 3, comment: "جيد لكن التوصيل تأخر يوماً." },
    { author: "مريم العنزي", rating: 5, comment: "السقف الكوف رائع، إضاءة ناعمة." },
    { author: "يوسف الحربي", rating: 4, comment: "الپانل الخشبي beautiful finish." },
  ];

  const reviewRows = prodRows.flatMap((p, idx) => {
    const r1 = reviewData[idx % reviewData.length];
    const r2 = reviewData[(idx + 3) % reviewData.length];
    return [
      {
        productId: p.id,
        authorName: r1.author,
        rating: r1.rating,
        comment: r1.comment,
      },
      {
        productId: p.id,
        authorName: r2.author,
        rating: r2.rating,
        comment: r2.comment,
      },
    ];
  });

  await db.insert(reviews).values(reviewRows);

  seeded = true;
}

export async function isSeededFlag() {
  return seeded;
}