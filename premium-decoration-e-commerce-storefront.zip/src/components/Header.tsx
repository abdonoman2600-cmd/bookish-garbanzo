"use client";

import { useState } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import LanguageSwitcher from "@/components/LanguageSwitcher";

export default function Header() {
  const { count, setOpen } = useCart();
  const [menu, setMenu] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-black/5 bg-cream/80 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand text-accent font-display text-xl">
            ر
          </span>
          <span className="font-display text-2xl text-brand">رشيد</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/" className="text-sm font-medium hover:text-brand">
            الرئيسية
          </Link>
          <Link href="/products" className="text-sm font-medium hover:text-brand">
            المنتجات
          </Link>
          <Link
            href="/products?featured=1"
            className="text-sm font-medium hover:text-brand"
          >
            مختارات
          </Link>
          <Link href="/checkout" className="text-sm font-medium hover:text-brand">
            إتمام الطلب
          </Link>
        </nav>

        <button
          onClick={() => setMenu((v) => !v)}
          className="flex h-11 w-11 items-center justify-center rounded-full border border-brand/20 bg-white text-brand md:hidden"
          aria-label="القائمة"
        >
          ☰
        </button>

        <LanguageSwitcher />
        <button
          onClick={() => setOpen(true)}
          className="relative flex h-11 w-11 items-center justify-center rounded-full border border-brand/20 bg-white text-brand transition hover:bg-brand hover:text-white"
          aria-label="سلة التسوق"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="9" cy="21" r="1" />
            <circle cx="20" cy="21" r="1" />
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
          </svg>
          {count > 0 && (
            <span className="absolute -top-1 -left-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-xs font-bold text-brand">
              {count}
            </span>
          )}
        </button>
      </div>
      {menu && (
        <div className="border-t border-black/5 bg-cream px-4 py-3 md:hidden">
          <nav className="flex flex-col gap-2">
            <Link href="/" onClick={() => setMenu(false)} className="py-2">
              الرئيسية
            </Link>
            <Link
              href="/products"
              onClick={() => setMenu(false)}
              className="py-2"
            >
              المنتجات
            </Link>
            <Link
              href="/products?featured=1"
              onClick={() => setMenu(false)}
              className="py-2"
            >
              مختارات
            </Link>
            <Link
              href="/checkout"
              onClick={() => setMenu(false)}
              className="py-2"
            >
              إتمام الطلب
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}