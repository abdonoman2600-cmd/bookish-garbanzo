"use client";

import { useEffect, useState } from "react";
import { CartItem } from "@/lib/cart";

export default function WhatsAppShare({ items }: { items: CartItem[] }) {
  const [phone, setPhone] = useState("+966500000000");

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d.settings?.whatsapp_number) setPhone(d.settings.whatsapp_number);
      })
      .catch(() => {});
  }, []);

  function share() {
    const lines = items.map((it) => `• ${it.name} × ${it.quantity}`).join("\n");
    const msg = `مرحباً، أرغب في طلب الأشكال التالية:\n${lines}\n\nالاسم:\nالجوال:\nالمدينة:\nالعنوان:`;
    const url = `https://wa.me/${phone.replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  }

  return (
    <button
      onClick={share}
      className="w-full rounded-full bg-green-600 py-3 text-center text-sm font-semibold text-white transition hover:bg-green-700"
    >
      مشاركة الطلب عبر WhatsApp
    </button>
  );
}