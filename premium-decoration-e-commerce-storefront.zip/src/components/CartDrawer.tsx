"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import WhatsAppShare from "@/components/WhatsAppShare";

export default function CartDrawer() {
  const { items, open, setOpen, removeItem, updateQty, subtotal, clear } =
    useCart();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm animate-fade-in"
        onClick={() => setOpen(false)}
      />
      <aside className="absolute left-0 top-0 h-full w-full max-w-md bg-cream shadow-2xl animate-[slideInRight_0.3s_ease-out]">
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b border-black/5 px-5 py-4">
            <h2 className="font-display text-xl text-brand">سلة التسوق</h2>
            <button
              onClick={() => setOpen(false)}
              className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-sand"
              aria-label="إغلاق"
            >
              ✕
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-5 py-4">
            {items.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center text-muted">
                <div className="text-5xl">🛒</div>
                <p className="mt-4">سلتك فارغة</p>
                <Link
                  href="/products"
                  onClick={() => setOpen(false)}
                  className="mt-4 rounded-full bg-brand px-5 py-2 text-sm text-cream"
                >
                  تصفح المنتجات
                </Link>
              </div>
            ) : (
              <ul className="space-y-4">
                {items.map((item) => (
                  <li
                    key={item.productId}
                    className="flex gap-3 rounded-2xl bg-white p-3 shadow-sm"
                  >
                    <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-sand">
                      {item.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={item.image}
                          alt={item.name}
                          className="h-full w-full object-cover"
                        />
                      ) : null}
                    </div>
                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-sm font-medium leading-snug">
                          {item.name}
                        </span>
                        <button
                          onClick={() => removeItem(item.productId)}
                          className="text-xs text-muted hover:text-red-600"
                        >
                          حذف
                        </button>
                      </div>
                      {/* price hidden per store preference */}
                      <div className="mt-2 flex items-center gap-2">
                        <button
                          onClick={() =>
                            updateQty(item.productId, item.quantity - 1)
                          }
                          className="h-7 w-7 rounded-full border border-black/10"
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-sm">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQty(item.productId, item.quantity + 1)
                          }
                          className="h-7 w-7 rounded-full border border-black/10"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {items.length > 0 && (
            <div className="border-t border-black/5 bg-white px-5 py-4">
              <WhatsAppShare items={items} />
              <button
                onClick={clear}
                className="mt-2 w-full text-xs text-muted hover:text-red-600"
              >
                إفراغ السلة
              </button>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}