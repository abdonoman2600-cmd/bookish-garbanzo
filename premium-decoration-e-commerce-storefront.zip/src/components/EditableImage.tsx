"use client";

import { useAdmin } from "@/lib/admin";
import { useRef, useState } from "react";

export default function EditableImage({
  src,
  alt = "",
  onSave,
  className = "",
  fill = false,
}: {
  src: string;
  alt?: string;
  onSave: (url: string) => Promise<void> | void;
  className?: string;
  fill?: boolean;
}) {
  const { editMode } = useAdmin();
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  if (!editMode) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={alt} className={className} />;
  }

  async function handleFile(file: File) {
    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.url) await onSave(data.url);
    setUploading(false);
  }

  async function handleUrl() {
    const url = prompt("أدخل رابط الصورة:", src);
    if (url) await onSave(url);
  }

  return (
    <div
      className={`relative ${fill ? "h-full w-full" : ""}`}
      onClick={(e) => e.preventDefault()}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt} className={className} />
      <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/40">
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            inputRef.current?.click();
          }}
          className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-brand shadow"
          disabled={uploading}
        >
          {uploading ? "..." : "رفع صورة"}
        </button>
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            handleUrl();
          }}
          className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-brand shadow"
        >
          رابط
        </button>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
        }}
      />
    </div>
  );
}