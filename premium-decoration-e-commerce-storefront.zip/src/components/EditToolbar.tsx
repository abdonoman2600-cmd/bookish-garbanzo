"use client";

import { useAdmin } from "@/lib/admin";
import { useState } from "react";

export default function EditToolbar() {
  const { isAdmin, editMode, setEditMode } = useAdmin();
  const [open, setOpen] = useState(false);
  const [colors, setColors] = useState({ brand: "", accent: "" });

  if (!isAdmin) return null;

  async function saveColor(key: string, value: string) {
    await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [key]: value }),
    });
    // apply immediately
    document.documentElement.style.setProperty(
      key === "brand_color" ? "--color-brand" : "--color-accent",
      value
    );
  }

  return (
    <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 flex flex-col items-center gap-2">
      {editMode && open && (
        <div className="rounded-2xl bg-white p-4 shadow-xl">
          <p className="mb-2 text-xs font-semibold text-brand">الألوان</p>
          <div className="flex gap-3">
            <label className="text-xs">
              علامة
              <input
                type="color"
                className="mt-1 block h-8 w-12"
                onChange={(e) => saveColor("brand_color", e.target.value)}
              />
            </label>
            <label className="text-xs">
              تمييز
              <input
                type="color"
                className="mt-1 block h-8 w-12"
                onChange={(e) => saveColor("accent_color", e.target.value)}
              />
            </label>
          </div>
        </div>
      )}
      <div className="flex gap-2">
        {editMode && (
          <button
            onClick={() => setOpen((v) => !v)}
            className="rounded-full bg-white px-4 py-3 text-sm font-bold text-brand shadow-lg"
          >
            🎨
          </button>
        )}
        <button
          onClick={() => setEditMode(!editMode)}
          className={`rounded-full px-6 py-3 text-sm font-bold shadow-lg transition ${
            editMode
              ? "bg-accent text-brand"
              : "bg-brand text-cream hover:bg-brand-light"
          }`}
        >
          {editMode ? "✓ تحرير (إيقاف)" : "✏️ تفعيل التحرير"}
        </button>
      </div>
    </div>
  );
}