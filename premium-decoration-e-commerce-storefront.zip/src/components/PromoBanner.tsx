"use client";

import Link from "next/link";
import { useState } from "react";
import EditableText from "@/components/EditableText";

export default function PromoBanner({ initial }: { initial: Record<string, string> }) {
  const [s, setS] = useState(initial);
  async function save(key: string, value: string) {
    setS((prev) => ({ ...prev, [key]: value }));
    await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [key]: value }),
    });
  }
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="relative overflow-hidden rounded-3xl bg-brand p-8 text-cream sm:p-12">
        <div className="relative z-10 max-w-xl">
          <h2 className="font-display text-3xl sm:text-4xl">
            <EditableText value={s.promo_title} onSave={(v) => save("promo_title", v)} />
          </h2>
          <p className="mt-3 text-cream/80">
            <EditableText value={s.promo_text} onSave={(v) => save("promo_text", v)} multiline />
          </p>
          <Link
            href="/products"
            className="mt-6 inline-block rounded-full bg-accent px-6 py-3 text-sm font-bold text-brand"
          >
            ابدأ التسوق
          </Link>
        </div>
        <div className="pointer-events-none absolute -left-10 -bottom-10 h-64 w-64 rounded-full bg-accent/20 blur-3xl" />
      </div>
    </section>
  );
}