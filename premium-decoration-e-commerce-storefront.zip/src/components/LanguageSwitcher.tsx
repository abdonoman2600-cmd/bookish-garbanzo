"use client";

import { useI18n } from "@/lib/i18n";

export default function LanguageSwitcher() {
  const { lang, setLang } = useI18n();
  return (
    <button
      onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      className="rounded-full border border-brand/20 bg-white px-3 py-1 text-xs font-semibold text-brand transition hover:bg-brand hover:text-cream"
    >
      {lang === "ar" ? "EN" : "AR"}
    </button>
  );
}