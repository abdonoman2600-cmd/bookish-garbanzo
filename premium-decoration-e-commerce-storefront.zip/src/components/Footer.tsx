import Link from "next/link";
import { getSettings } from "@/lib/settings";

export default async function Footer() {
  const s = await getSettings();
  return (
    <footer className="mt-20 border-t border-black/5 bg-brand text-cream">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <h3 className="font-display text-2xl text-accent">{s.store_name}</h3>
            <p className="mt-3 text-sm leading-relaxed text-cream/80">
              متجر متخصص في أعمال الديكور وجبسن بورد — أسقف مستعارة، ديكور
              جداري، إضاءة وملحقات، لمن لديه خبرة في الديكور والجبسن بورد
              والرنج.
            </p>
          </div>
          <div>
            <h4 className="font-semibold">روابط سريعة</h4>
            <ul className="mt-3 space-y-2 text-sm text-cream/80">
              <li>
                <Link href="/" className="hover:text-accent">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/products" className="hover:text-accent">
                  المنتجات
                </Link>
              </li>
              <li>
                <Link href="/checkout" className="hover:text-accent">
                  إتمام الطلب
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold">تواصل معنا</h4>
            <p className="mt-3 text-sm text-cream/80">{s.footer_address}</p>
            <p className="text-sm text-cream/80">{s.footer_phone}</p>
            <p className="text-sm text-cream/80">{s.footer_email}</p>
          </div>
        </div>
        <div className="mt-10 border-t border-cream/10 pt-6 text-center text-xs text-cream/60">
          © {new Date().getFullYear()} رشيد. جميع الحقوق محفوظة.
        </div>
      </div>
    </footer>
  );
}