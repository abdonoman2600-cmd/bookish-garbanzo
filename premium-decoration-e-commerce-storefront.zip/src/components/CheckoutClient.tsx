"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import { money } from "@/lib/format";
import WhatsAppShare from "@/components/WhatsAppShare";

export default function CheckoutClient() {
  const { items, subtotal, clear } = useCart();
  const [settings, setSettings] = useState<Record<string, string>>({});
  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        setSettings(d.settings ?? {});
      })
      .catch(() => {});
  }, []);
  const shippingCost =
    subtotal >= Number(settings.free_shipping_threshold || 500)
      ? 0
      : Number(settings.shipping_cost || 25);
  const taxRate = Number(settings.tax_rate || 15) / 100;
  const taxAmount = (subtotal + shippingCost) * taxRate;
  const total = subtotal + shippingCost + taxAmount;

  const [form, setForm] = useState({
    customerName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    notes: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<number | null>(null);
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (items.length === 0) return;
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items,
          subtotal,
          shippingCost,
          taxAmount,
          total,
          paymentMethod: "cod",
        }),
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setSuccess(data.order.id);
      clear();
    } catch {
      setError("حدث خطأ. يرجى المحاولة مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  }

  if (success) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="text-6xl">✅</div>
        <h1 className="mt-4 font-display text-3xl text-brand">تم استلام طلبك</h1>
        <p className="mt-2 text-muted">
          رقم الطلب: <span className="font-bold text-brand">#{success}</span>
        </p>
        <p className="mt-1 text-sm text-muted">
          سنتواصل معك قريباً لتأكيد الطلب والشحن.
        </p>
        <Link
          href="/products"
          className="mt-6 inline-block rounded-full bg-brand px-6 py-3 text-sm font-bold text-cream"
        >
          مواصلة التسوق
        </Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="text-6xl">🛒</div>
        <h1 className="mt-4 font-display text-3xl text-brand">سلتك فارغة</h1>
        <Link
          href="/products"
          className="mt-6 inline-block rounded-full bg-brand px-6 py-3 text-sm font-bold text-cream"
        >
          تصفح المنتجات
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-3xl text-brand">إتمام الطلب</h1>
      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-6 shadow-sm">
          <h2 className="font-display text-xl text-brand">معلومات العميل</h2>
          <input
            required
            value={form.customerName}
            onChange={(e) => setForm({ ...form, customerName: e.target.value })}
            placeholder="الاسم الكامل"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="البريد الإلكتروني (اختياري)"
            type="email"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="رقم الجوال"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          <input
            required
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            placeholder="المدينة"
            className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          <textarea
            required
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            placeholder="العنوان التفصيلي"
            rows={3}
            className="w-full rounded-2xl border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          <textarea
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            placeholder="ملاحظات (اختياري)"
            rows={2}
            className="w-full rounded-2xl border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <WhatsAppShare items={items} />
          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-full bg-brand py-3 text-sm font-bold text-cream transition hover:bg-brand-light disabled:opacity-60"
          >
            {submitting ? "جارٍ إرسال الطلب..." : "حفظ الطلب في النظام"}
          </button>
        </form>

        <div className="rounded-3xl bg-white p-6 shadow-sm">
          <h2 className="font-display text-xl text-brand">ملخص الطلب</h2>
          <ul className="mt-4 space-y-3">
            {items.map((it) => (
              <li key={it.productId} className="flex items-center justify-between text-sm">
                <span>
                  {it.name} × {it.quantity}
                </span>
                <span className="font-semibold text-brand">
                  {money(it.price * it.quantity)} ر.س
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-4 border-t border-black/5 pt-4 text-sm text-muted">
            سيتم إرسال طلبك (الأشكال المختارة) إلى المالك عبر WhatsApp.
          </div>
          <p className="mt-3 text-xs text-muted">
            الدفع عند الاستلام. سيتم تأكيد الطلب عبر الجوال.
          </p>
        </div>
      </div>
    </div>
  );
}