"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/lib/cart";
import { useAdmin } from "@/lib/admin";
import { money } from "@/lib/format";
import ProductCard from "@/components/ProductCard";
import EditableText from "@/components/EditableText";
import EditableImage from "@/components/EditableImage";

type Product = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  price: string | number;
  compareAtPrice: string | number | null;
  categoryId: number | null;
  images: string[] | null;
  stock: number | null;
  featured: boolean | null;
};

type Category = { id: number; name: string; slug: string } | null;

type Review = {
  id: number;
  productId: number;
  authorName: string;
  rating: number;
  comment: string | null;
  createdAt: Date | string | null;
};

export default function ProductDetailClient({
  product,
  category,
  reviews: initialReviews,
  related,
}: {
  product: Product;
  category: Category;
  reviews: Review[];
  related: Product[];
}) {
  const { addItem } = useCart();
  const { editMode } = useAdmin();
  const [prod, setProd] = useState(product);
  const images = prod.images && prod.images.length > 0 ? prod.images : [];
  const [active, setActive] = useState(0);
  const [qty, setQty] = useState(1);
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [author, setAuthor] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const price = Number(prod.price);
  const compare = prod.compareAtPrice ? Number(prod.compareAtPrice) : null;

  async function saveField(field: string, value: any) {
    const updated = { ...prod, [field]: value };
    setProd(updated);
    await fetch("/api/admin/products", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: prod.id,
        name: field === "name" ? value : prod.name,
        slug: prod.slug,
        description: field === "description" ? value : prod.description,
        price: field === "price" ? value : prod.price,
        compareAtPrice: prod.compareAtPrice,
        categoryId: prod.categoryId,
        images: field === "images" ? value : prod.images,
        stock: prod.stock,
        featured: prod.featured,
      }),
    });
  }

  async function submitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!author.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          authorName: author,
          rating,
          comment,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setReviews((prev) => [data.review, ...prev]);
        setAuthor("");
        setComment("");
        setRating(5);
      }
    } finally {
      setSubmitting(false);
    }
  }

  const avg =
    reviews.length > 0
      ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
      : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      {/* Breadcrumb */}
      <nav className="text-sm text-muted">
        <Link href="/" className="hover:text-brand">
          الرئيسية
        </Link>{" "}
        /{" "}
        <Link href="/products" className="hover:text-brand">
          المنتجات
        </Link>{" "}
        / <span className="text-ink">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-sand">
            {images[active] && (
              editMode ? (
                <EditableImage
                  src={images[active]}
                  alt={prod.name}
                  onSave={(url) => {
                    const newImgs = [...images];
                    newImgs[active] = url;
                    saveField("images", newImgs);
                  }}
                  className="h-full w-full object-cover"
                  fill
                />
              ) : (
                <Image
                  src={images[active]}
                  alt={prod.name}
                  fill
                  priority
                  className="object-cover"
                />
              )
            )}
          </div>
          {images.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  className={`relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl border-2 ${
                    i === active ? "border-brand" : "border-transparent"
                  }`}
                >
                  <Image src={img} alt="" fill className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          {category && (
            <Link
              href={`/products?category=${category.slug}`}
              className="text-xs font-semibold uppercase tracking-wider text-accent"
            >
              {category.name}
            </Link>
          )}
          <h1 className="mt-2 font-display text-3xl text-brand sm:text-4xl">
            {editMode ? (
              <EditableText value={prod.name} onSave={(v) => saveField("name", v)} />
            ) : (
              prod.name
            )}
          </h1>
          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="text-accent">
              {"★".repeat(Math.round(avg))}
              {"☆".repeat(5 - Math.round(avg))}
            </span>
            <span className="text-muted">
              {avg.toFixed(1)} ({reviews.length} تقييم)
            </span>
          </div>

          {editMode && (
            <div className="mt-5 flex items-baseline gap-3">
              <span className="text-3xl font-bold text-brand">
                <EditableText value={String(prod.price)} onSave={(v) => saveField("price", v)} />{" "}
                ر.س
              </span>
            </div>
          )}

          <p className="mt-5 leading-relaxed text-ink/80">
            {editMode ? (
              <EditableText
                value={prod.description ?? ""}
                onSave={(v) => saveField("description", v)}
                multiline
              />
            ) : (
              prod.description
            )}
          </p>

          <div className="mt-6 flex items-center gap-3">
            <div className="flex items-center rounded-full border border-black/10">
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="px-4 py-2"
              >
                −
              </button>
              <span className="w-8 text-center">{qty}</span>
              <button
                onClick={() => setQty((q) => q + 1)}
                className="px-4 py-2"
              >
                +
              </button>
            </div>
            <button
              onClick={() =>
                addItem(
                  {
                    productId: prod.id,
                    slug: prod.slug,
                    name: prod.name,
                    price,
                    image: images[0] ?? null,
                  },
                  qty
                )
              }
              className="flex-1 rounded-full bg-brand py-3 text-sm font-bold text-cream transition hover:bg-brand-light"
            >
              أضف إلى السلة
            </button>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-2xl bg-sand p-3">
              <p className="text-muted">المخزون</p>
              <p className="font-semibold text-brand">
                {editMode ? (
                  <EditableText
                    value={String(prod.stock ?? 0)}
                    onSave={(v) => saveField("stock", v)}
                  />
                ) : (
                  prod.stock ?? 0
                )}{" "}
                متوفر
              </p>
            </div>
            <div className="rounded-2xl bg-sand p-3">
              <p className="text-muted">الشحن</p>
              <p className="font-semibold text-brand">2-5 أيام عمل</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-16">
        <h2 className="font-display text-2xl text-brand">التقييمات والمراجعات</h2>
        <div className="mt-6 grid gap-8 lg:grid-cols-2">
          <div className="space-y-4">
            {reviews.length === 0 && (
              <p className="text-muted">لا توجد تقييمات بعد. كن أول من يقيّم!</p>
            )}
            {reviews.map((r) => (
              <div key={r.id} className="rounded-2xl bg-white p-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-brand">{r.authorName}</span>
                  <span className="text-accent">
                    {"★".repeat(r.rating)}
                    {"☆".repeat(5 - r.rating)}
                  </span>
                </div>
                {r.comment && (
                  <p className="mt-2 text-sm text-ink/80">{r.comment}</p>
                )}
                <p className="mt-2 text-xs text-muted">
                  {r.createdAt ? new Date(r.createdAt).toLocaleDateString("ar-SA") : ""}
                </p>
              </div>
            ))}
          </div>

          <form
            onSubmit={submitReview}
            className="rounded-3xl bg-white p-6 shadow-sm"
          >
            <h3 className="font-display text-xl text-brand">أضف تقييمك</h3>
            <div className="mt-4 space-y-3">
              <input
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="اسمك"
                required
                className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
              />
              <select
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="w-full rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
              >
                {[5, 4, 3, 2, 1].map((n) => (
                  <option key={n} value={n}>
                    {n} نجوم
                  </option>
                ))}
              </select>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="تعليقك (اختياري)"
                rows={4}
                className="w-full rounded-2xl border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
              />
              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-full bg-brand py-3 text-sm font-bold text-cream transition hover:bg-brand-light disabled:opacity-60"
              >
                {submitting ? "جارٍ الإرسال..." : "إرسال التقييم"}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="font-display text-2xl text-brand">منتجات ذات صلة</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}