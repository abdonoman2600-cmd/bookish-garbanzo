"use client";

import { useMemo, useState } from "react";
import ProductCard from "@/components/ProductCard";
import { money } from "@/lib/format";

type Category = { id: number; name: string; slug: string };
type Product = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  price: string | number;
  compareAtPrice: string | number | null;
  categoryId: number | null;
  images: string[] | null;
  stock: number | null;
  featured: boolean | null;
};

export default function ProductsClient({
  categories,
  products,
  initialCategory,
  initialFeatured,
  initialQuery,
}: {
  categories: Category[];
  products: Product[];
  initialCategory: string;
  initialFeatured: boolean;
  initialQuery: string;
}) {
  const [category, setCategory] = useState(initialCategory);
  const [featuredOnly, setFeaturedOnly] = useState(initialFeatured);
  const [query, setQuery] = useState(initialQuery);
  const [sort, setSort] = useState("featured");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const filtered = useMemo(() => {
    let list = [...products];
    if (category) {
      const cat = categories.find((c) => c.slug === category);
      if (cat) list = list.filter((p) => p.categoryId === cat.id);
    }
    if (featuredOnly) list = list.filter((p) => p.featured);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.description ?? "").toLowerCase().includes(q)
      );
    }
    const min = minPrice ? parseFloat(minPrice) : null;
    const max = maxPrice ? parseFloat(maxPrice) : null;
    if (min !== null) list = list.filter((p) => Number(p.price) >= min);
    if (max !== null) list = list.filter((p) => Number(p.price) <= max);

    switch (sort) {
      case "price-asc":
        list.sort((a, b) => Number(a.price) - Number(b.price));
        break;
      case "price-desc":
        list.sort((a, b) => Number(b.price) - Number(a.price));
        break;
      case "name":
        list.sort((a, b) => a.name.localeCompare(b.name, "ar"));
        break;
      default:
        list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }
    return list;
  }, [products, categories, category, featuredOnly, query, sort, minPrice, maxPrice]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-accent">
            المتجر
          </p>
          <h1 className="mt-2 font-display text-3xl text-brand">المنتجات</h1>
          <p className="mt-1 text-sm text-muted">
            {filtered.length} من {products.length} منتج
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="mt-6 grid gap-3 rounded-3xl bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="بحث..."
          className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        >
          <option value="">كل التصنيفات</option>
          {categories.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        >
          <option value="featured">الأكثر تميزاً</option>
          <option value="price-asc">السعر: من الأقل</option>
          <option value="price-desc">السعر: من الأعلى</option>
          <option value="name">الاسم</option>
        </select>
        <input
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
          placeholder="الحد الأدنى"
          type="number"
          className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        />
        <input
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
          placeholder="الحد الأقصى"
          type="number"
          className="rounded-full border border-black/10 px-4 py-2 text-sm outline-none focus:border-brand"
        />
        <label className="flex items-center gap-2 rounded-full border border-black/10 px-4 py-2 text-sm">
          <input
            type="checkbox"
            checked={featuredOnly}
            onChange={(e) => setFeaturedOnly(e.target.checked)}
          />
          مختارات فقط
        </label>
      </div>

      {filtered.length === 0 ? (
        <div className="mt-12 rounded-3xl bg-white p-12 text-center text-muted">
          لا توجد منتجات مطابقة.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}