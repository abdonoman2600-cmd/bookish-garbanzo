"use client";

import { useState } from "react";
import Link from "next/link";
import EditableText from "@/components/EditableText";
import EditableImage from "@/components/EditableImage";

type Settings = Record<string, string>;

export default function HeroSection({ initial }: { initial: Settings }) {
  const [s, setS] = useState(initial);

  async function save(key: string, value: string) {
    setS((prev) => ({ ...prev, [key]: value }));
    await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [key]: value }),
    });
  }

  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        <EditableImage
          src={s.hero_image}
          alt="رشيد ديكور"
          onSave={(url) => save("hero_image", url)}
          className="h-full w-full object-cover"
          fill
        />
        <div className="absolute inset-0 bg-gradient-to-l from-brand/90 via-brand/70 to-brand/40" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 sm:py-32 lg:py-40">
        <div className="max-w-2xl">
          <span className="inline-block rounded-full bg-accent/20 px-4 py-1 text-xs font-semibold uppercase tracking-wider text-accent-soft">
            متجر رشيد
          </span>
          <h1 className="mt-6 font-display text-4xl leading-tight text-cream sm:text-5xl lg:text-6xl">
            <EditableText
              value={s.store_name}
              onSave={(v) => save("store_name", v)}
            />
            <span className="block text-accent">
              <EditableText
                value={s.hero_title}
                onSave={(v) => save("hero_title", v)}
              />
            </span>
          </h1>
          <p className="mt-6 text-base leading-relaxed text-cream/85 sm:text-lg">
            <EditableText
              value={s.hero_subtitle}
              onSave={(v) => save("hero_subtitle", v)}
              multiline
            />
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/products"
              className="rounded-full bg-accent px-7 py-3 text-sm font-bold text-brand transition hover:bg-accent-soft"
            >
              <EditableText
                value={s.hero_cta}
                onSave={(v) => save("hero_cta", v)}
              />
            </Link>
            <Link
              href="/products?featured=1"
              className="rounded-full border border-cream/40 px-7 py-3 text-sm font-semibold text-cream transition hover:bg-cream/10"
            >
              المختارات
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}