"use client";

import { useAdmin } from "@/lib/admin";
import { useState } from "react";

export default function EditableText({
  value,
  onSave,
  className = "",
  multiline = false,
  as: Tag = "span",
}: {
  value: string;
  onSave: (v: string) => Promise<void> | void;
  className?: string;
  multiline?: boolean;
  as?: any;
}) {
  const { editMode } = useAdmin();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  if (!editMode) {
    return <Tag className={className}>{value}</Tag>;
  }

  if (editing) {
    const Comp = multiline ? "textarea" : "input";
    return (
      <Comp
        autoFocus
        value={draft}
        onChange={(e: any) => setDraft(e.target.value)}
        onBlur={async () => {
          await onSave(draft);
          setEditing(false);
        }}
        onKeyDown={(e: any) => {
          if (e.key === "Enter" && !multiline) {
            e.currentTarget.blur();
          }
        }}
        className={`${className} rounded border border-accent bg-white px-2 py-1 text-ink outline-none`}
        rows={multiline ? 3 : undefined}
      />
    );
  }

  return (
    <Tag
      className={`${className} cursor-pointer rounded outline-dashed outline-1 outline-accent/40 hover:outline-accent`}
      onClick={() => {
        setDraft(value);
        setEditing(true);
      }}
      title="انقر للتعديل"
    >
      {value}
    </Tag>
  );
}