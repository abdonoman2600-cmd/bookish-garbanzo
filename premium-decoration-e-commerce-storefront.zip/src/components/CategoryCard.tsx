"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useAdmin } from "@/lib/admin";
import EditableText from "@/components/EditableText";
import EditableImage from "@/components/EditableImage";

type Cat = { id: number; name: string; slug: string; description: string | null; image: string | null };

export default function CategoryCard({ category }: { category: Cat }) {
  const { editMode } = useAdmin();
  const [c, setC] = useState(category);

  async function saveField(field: string, value: any) {
    const updated = { ...c, [field]: value };
    setC(updated);
    await fetch("/api/admin/categories", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: c.id,
        name: field === "name" ? value : c.name,
        slug: c.slug,
        description: field === "description" ? value : c.description,
        image: field === "image" ? value : c.image,
      }),
    });
  }

  return (
    <Link
      href={`/products?category=${c.slug}`}
      className="group relative overflow-hidden rounded-3xl bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        {c.image && (
          editMode ? (
            <EditableImage
              src={c.image}
              alt={c.name}
              onSave={(url) => saveField("image", url)}
              className="h-full w-full object-cover"
              fill
            />
          ) : (
            <Image
              src={c.image}
              alt={c.name}
              fill
              className="object-cover transition duration-500 group-hover:scale-105"
            />
          )
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-brand/80 to-transparent" />
      </div>
      <div className="absolute bottom-0 right-0 left-0 p-4 text-cream">
        <h3 className="font-display text-lg">
          {editMode ? (
            <EditableText value={c.name} onSave={(v) => saveField("name", v)} />
          ) : (
            c.name
          )}
        </h3>
        <p className="text-xs text-cream/80 line-clamp-1">{c.description}</p>
      </div>
    </Link>
  );
}