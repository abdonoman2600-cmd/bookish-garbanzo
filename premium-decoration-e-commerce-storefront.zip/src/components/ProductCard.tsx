"use client";

import Link from "next/link";
import Image from "next/image";
import { money } from "@/lib/format";
import { useCart } from "@/lib/cart";
import { useAdmin } from "@/lib/admin";
import { useState } from "react";
import EditableText from "@/components/EditableText";
import EditableImage from "@/components/EditableImage";

type Product = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  price: string | number;
  compareAtPrice?: string | number | null;
  categoryId: number | null;
  images: string[] | null;
  stock: number | null;
  featured: boolean | null;
};

export default function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const { editMode } = useAdmin();
  const [p, setP] = useState(product);
  const img = p.images?.[0] ?? null;
  const price = Number(p.price);
  const compare = p.compareAtPrice ? Number(p.compareAtPrice) : null;

  async function saveField(field: string, value: any) {
    const updated = { ...p, [field]: value };
    setP(updated);
    await fetch("/api/admin/products", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: p.id,
        name: field === "name" ? value : p.name,
        slug: p.slug,
        description: p.description,
        price: field === "price" ? value : p.price,
        compareAtPrice: p.compareAtPrice,
        categoryId: p.categoryId,
        images: field === "images" ? value : p.images,
        stock: p.stock,
        featured: p.featured,
      }),
    });
  }

  const imageBlock = img ? (
    editMode ? (
      <EditableImage
        src={img}
        alt={p.name}
        onSave={(url) => saveField("images", [url, ...(p.images?.slice(1) ?? [])])}
        className="h-full w-full object-cover"
        fill
      />
    ) : (
      <Image
        src={img}
        alt={p.name}
        fill
        className="object-cover transition duration-500 group-hover:scale-105"
      />
    )
  ) : null;

  return (
    <article className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
      {editMode ? (
        <div className="relative block aspect-[4/3] overflow-hidden bg-sand">
          {imageBlock}
          {compare && compare > price && (
            <span className="absolute right-3 top-3 rounded-full bg-accent px-2 py-1 text-xs font-bold text-brand">
              خصم {Math.round((1 - price / compare) * 100)}%
            </span>
          )}
        </div>
      ) : (
        <Link href={`/products/${p.slug}`} className="relative block aspect-[4/3] overflow-hidden bg-sand">
          {imageBlock}
          {compare && compare > price && (
            <span className="absolute right-3 top-3 rounded-full bg-accent px-2 py-1 text-xs font-bold text-brand">
              خصم {Math.round((1 - price / compare) * 100)}%
            </span>
          )}
        </Link>
      )}
      <div className="flex flex-1 flex-col p-4">
        <Link href={`/products/${p.slug}`}>
          <h3 className="line-clamp-2 text-sm font-semibold text-ink transition group-hover:text-brand">
            {editMode ? (
              <EditableText value={p.name} onSave={(v) => saveField("name", v)} />
            ) : (
              p.name
            )}
          </h3>
        </Link>
        {editMode && (
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-base font-bold text-brand">
              <EditableText
                value={String(p.price)}
                onSave={(v) => saveField("price", v)}
              />{" "}
              ر.س
            </span>
          </div>
        )}
        <div className="mt-auto pt-3">
          <button
            onClick={() =>
              addItem(
                {
                  productId: p.id,
                  slug: p.slug,
                  name: p.name,
                  price,
                  image: img,
                },
                1
              )
            }
            className="w-full rounded-full border border-brand/20 bg-cream py-2 text-xs font-semibold text-brand transition hover:bg-brand hover:text-cream"
          >
            أضف إلى السلة
          </button>
        </div>
      </div>
    </article>
  );
}