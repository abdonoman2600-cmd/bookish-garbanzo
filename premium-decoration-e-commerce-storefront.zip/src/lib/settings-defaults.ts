export const DEFAULT_SETTINGS: Record<string, string> = {
  store_name: "رشيد",
  hero_title: "أعمال ديكور وجبسن بورد",
  hero_subtitle:
    "تشكيلات مختارة من الأسقف المستعارة، الديكور الجداري، الإضاءة والملحقات — لمن لديه خبرة في الديكور والجبسن بورد والرنج.",
  hero_image:
    "https://images.pexels.com/photos/8082226/pexels-photo-8082226.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  hero_cta: "تصفح المنتجات",
  promo_title: "خصم 15% على أول طلب",
  promo_text: "استخدم الكود RASHID15 عند إتمام الطلب. عرض لفترة محدودة.",
  promo_code: "RASHID15",
  footer_phone: "+966 50 000 0000",
  footer_email: "info@rashid-decor.sa",
  footer_address: "الرياض، المملكة العربية السعودية",
  whatsapp_number: "+966500000000",
  shipping_cost: "25",
  tax_rate: "15",
  free_shipping_threshold: "500",
  brand_color: "#1f3a2e",
  accent_color: "#c9a227",
};