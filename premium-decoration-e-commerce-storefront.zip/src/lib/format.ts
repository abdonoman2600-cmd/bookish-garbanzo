export function money(n: number | string) {
  const v = typeof n === "string" ? parseFloat(n) : n;
  return v.toLocaleString("ar-SA", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function stars(rating: number) {
  return "★".repeat(rating) + "☆".repeat(5 - rating);
}