"use client";

import { createContext, useContext, useEffect, useState } from "react";

type Lang = "ar" | "en";

const dict: Record<Lang, Record<string, string>> = {
  ar: {
    home: "الرئيسية",
    products: "المنتجات",
    featured: "مختارات",
    checkout: "إتمام الطلب",
    cart: "سلة التسوق",
    search: "بحث...",
    addToCart: "أضف إلى السلة",
    price: "السعر",
    stock: "المخزون",
    available: "متوفر",
    reviews: "التقييمات",
    submitReview: "إرسال التقييم",
    name: "الاسم",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    logout: "تسجيل خروج",
    account: "حسابي",
    orders: "طلباتي",
    admin: "لوحة التحكم",
    language: "اللغة",
    emptyCart: "سلتك فارغة",
    browseProducts: "تصفح المنتجات",
    total: "المجموع",
    confirmOrder: "تأكيد الطلب",
    shipping: "الشحن",
    tax: "الضريبة",
    discount: "الخصم",
    subtotal: "المجموع الفرعي",
    cod: "الدفع عند الاستلام",
    about: "من نحن",
    contact: "اتصل بنا",
    faq: "الأسئلة الشائعة",
    noProducts: "لا توجد منتجات.",
  },
  en: {
    home: "Home",
    products: "Products",
    featured: "Featured",
    checkout: "Checkout",
    cart: "Cart",
    search: "Search...",
    addToCart: "Add to Cart",
    price: "Price",
    stock: "Stock",
    available: "available",
    reviews: "Reviews",
    submitReview: "Submit Review",
    name: "Name",
    login: "Login",
    register: "Register",
    logout: "Logout",
    account: "My Account",
    orders: "My Orders",
    admin: "Admin",
    language: "Language",
    emptyCart: "Your cart is empty",
    browseProducts: "Browse Products",
    total: "Total",
    confirmOrder: "Confirm Order",
    shipping: "Shipping",
    tax: "Tax",
    discount: "Discount",
    subtotal: "Subtotal",
    cod: "Cash on Delivery",
    about: "About Us",
    contact: "Contact",
    faq: "FAQ",
    noProducts: "No products found.",
  },
};

type I18nContextValue = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
  dir: "rtl" | "ltr";
};

const I18nContext = createContext<I18nContextValue>({
  lang: "ar",
  setLang: () => {},
  t: (k) => k,
  dir: "rtl",
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  useEffect(() => {
    const saved = document.cookie.match(/lang=([^;]+)/)?.[1] as Lang | undefined;
    if (saved === "ar" || saved === "en") setLangState(saved);
  }, []);

  function setLang(l: Lang) {
    setLangState(l);
    document.cookie = `lang=${l};path=/;max-age=31536000`;
    document.documentElement.lang = l;
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
  }

  const t = (key: string) => dict[lang][key] ?? key;

  return (
    <I18nContext.Provider value={{ lang, setLang, t, dir: lang === "ar" ? "rtl" : "ltr" }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}