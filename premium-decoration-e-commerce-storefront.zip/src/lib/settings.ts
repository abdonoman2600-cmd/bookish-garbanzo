import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

import { DEFAULT_SETTINGS } from "@/lib/settings-defaults";
export { DEFAULT_SETTINGS };

export async function getSettings(): Promise<Record<string, string>> {
  try {
    const rows = await db.select().from(siteSettings);
    const map: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const r of rows) {
      if (r.value !== null) map[r.key] = r.value;
    }
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function setSetting(key: string, value: string) {
  const existing = await db
    .select()
    .from(siteSettings)
    .where(eq(siteSettings.key, key));
  if (existing.length > 0) {
    await db
      .update(siteSettings)
      .set({ value, updatedAt: new Date() })
      .where(eq(siteSettings.key, key));
  } else {
    await db.insert(siteSettings).values({ key, value });
  }
}