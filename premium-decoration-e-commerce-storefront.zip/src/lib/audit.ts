import { db } from "@/db";
import { auditLogs } from "@/db/schema";

export async function audit(userId: number | null, action: string, entity?: string, entityId?: number, details?: string) {
  try {
    await db.insert(auditLogs).values({ userId, action, entity, entityId, details });
  } catch {
    /* ignore */
  }
}